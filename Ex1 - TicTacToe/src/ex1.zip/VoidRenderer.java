public class VoidRenderer implements Renderer {
    @Override
    public void renderBoard(Board board) {

    }
}
